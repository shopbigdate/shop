<template>
	<div>
		<div class="head">
			<div class="head_first">
				<a href="">🏠京东首页</a>
			</div>
			<div class="head_second">
				<li>
					{{loginInfo}}
				</li>
				<li>
					<a v-on:click="loginAndOut()" style="cursor:pointer">{{loginStatus}}</a>
				</li>
				<li class="head_second_li">丨</li>
				<li>
					<router-link to="/register" class="f10">免费注册</router-link>
				</li>
				<li class="head_second_li">丨</li>
				<li>
					<router-link to="/order">我的订单</router-link>
				</li>
				<li class="head_second_li">丨</li>
				<li class="head_second_li_1">
					<a href="">我的京东 ∨</a>
					<ul>
						<li>
							<a href="">待处理订单</a>
						</li>
						<li>
							<a href="">返修退还货</a>
						</li>
						<li>
							<a href="">降价商品</a>
						</li>
						<li>
							<a href="">消息</a>
						</li>
						<li>
							<a href="">我的问答</a>
						</li>
						<li>
							<a href="">我的帮助</a>
						</li>
					</ul>
				</li>
				<li class="head_second_li">丨</li>
				<li>
					<a href="">京东会员</a>
				</li>
				<li class="head_second_li">丨</li>
				<li class="head_second_li_1">
					<a href="">企业采购 ∨</a>
					<ul>
						<li>
							<a href="">企业购</a>
						</li>
						<li>
							<a href="">商用场景馆</a>
						</li>
						<li>
							<a href="">工业品</a>
						</li>
						<li>
							<a href="">礼品卡</a>
						</li>
					</ul>
				</li>
				<li class="head_second_li">丨</li>
				<li class="head_second_li_1">
					<a href="">客服服务 ∨</a>
					<ul>
						<li>
							<a href="">----</a>
						</li>
						<li>
							<a href="">----</a>
						</li>
						<li>
							<a href="">----</a>
						</li>
						<li>
							<a href="">----</a>
						</li>
					</ul>
				</li>
				<li class="head_second_li">丨</li>
				<li class="head_second_li_1">
					<a href="">网站导航 ∨</a>
					<ul>
						<li>
							<a href="">----</a>
						</li>
						<li>
							<a href="">----</a>
						</li>
						<li>
							<a href="">----</a>
						</li>
						<li>
							<a href="">----</a>
						</li>
					</ul>
				</li>
				<li class="head_second_li">丨</li>
				<li>
					<a href="">手机京东</a>
				</li>
			</div>
		</div>
		<div class="second">
			<a href="" class="second_a_1"><img alt="" src="../../static/images/jdlogo-201708-@1x.png"></a>
			<a href="" class="second_a_2"><img alt="" src="../../static/images/cart-icon.png"></a>
			<input type="text" class="second_input_1">
			<button class="second_button_1"><strong>搜索</strong></button>
		</div>
		<div class="body">
			<div class="body_div_1">
				<font class="body_div_1_font_1">全部商品</font>
				<div>
					<div class="body_div_1_div_1">
						<table>
							<tr>
								<td class="body_div_1_div_1_font_1">
									<input type="checkbox" v-model="checkAll" @click="selectAll" class="body_div_1_div_1_input_1" />
								</td>
								<td class="body_div_1_div_1_font_2">
									商品名称
								</td>
								<td class="body_div_1_div_1_font_3">
									商品价格
								</td>
								<td class="body_div_1_div_1_font_4">
									商品数量
								</td>
								<td class="body_div_1_div_1_font_5">
									商品总额
								</td>
								<td class="body_div_1_div_1_font_6">
									操作
								</td>
							</tr>

							<div class="body_div_1_div_2">
								<tr v-for="(item,index) in infoList">

									<td>
										<input type="checkbox" :value="item.shopping_car_id" v-model="checkItem" @change="selectOne(index)" class="body_div_1_div_1_input_1">
									</td>
									<td class="body_div_1_div_2_div_1">
										<router-link :to="{path:'/search',query: {goods_id:item.goods_id}}">{{item.goods_name}}</router-link>
									</td>
									<td class="body_div_1_div_2_div_2">{{item.goods_price}}</td>

									<td class="body_div_1_div_2_div_3">
										<button class="body_div_1_div_2_div_4_input_1" @click="reduce(index)">-</button>
										<input class="body_div_1_div_2_div_4_input_2" type="text" v-model="item.goods_number" />
										<button class="body_div_1_div_2_div_4_input_3" @click="add(index)">+</button>
									</td>

									<td class="body_div_1_div_2_div_5">
										{{item.goods_price*item.goods_number}}
									</td>
									<td class="body_div_1_div_2_div_6">
										<button class="btn btn-danger" @click="del(index)">移除</button>
									</td>
								</tr>
							</div>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="third">
			<div class="selementcar">
				金额总计:{{sum}} 商品数量:{{count}}
			</div>
			<router-link to="/Order">
				<input class="body_div_2_a_4" type="button" value="" @click="Settlement"></input>
			</router-link>
			<hr class="third_hr_1">
			<ul class="third_ul_1">
				<li>
					<a href="">关于我们</a>
				</li>
				<li>
					<a href="">联系我们</a>
				</li>
				<li>
					<a href="">人才招聘</a>
				</li>
				<li>
					<a href="">商家入驻</a>
				</li>
				<li>
					<a href="">广告招租</a>
				</li>
				<li>
					<a href="">广告服务</a>
				</li>
				<li>
					<a href="">手机京东</a>
				</li>
				<li>
					<a href="">友情链接</a>
				</li>
				<li>
					<a href="">销售联盟</a>
				</li>
				<li>
					<a href="">京东社区</a>
				</li>
				<li>
					<a href="">京东公益</a>
				</li>
				<li style="border:none;">
					<a href="">English Site</a>
				</li>
			</ul>
			<font class="third_font_1">Copyright©2004-2019 京东JD.com 版权所有</font>
		</div>
	</div>
</template>

<script>
	import axios from 'axios';
	export default {
		name: 'ShoppingCar',
		data() {
			return {
				input: {
					orderDetail: [
						//{shopping_car_id:1,goods_name:"冰淇凌",goods_price:10.0,goods_number:3,isbuy:false}
					],
					order_sum: 0
				},
				infoList: [],
				checkItem: [],
				checkAll: false,
				maxstore: 0,
				loginInfo: "",
				loginStatus: "您好，请登录",
				userId: ""
			}
		},

		mounted: function() {
			this.searchshoppingcar();
			this.getSession();
			var self = this;
			var url = 'http://localhost:8888/goods/getUserName';
			axios.post(url).then(function(response) {
				self.loginInfo = response.data;
			})
		},

		methods: {
			del: function(index) {
				var self = this
				let formData = JSON.stringify({
					goods_id: this.infoList[index].goods_id
				});
				var url = "http://localhost:8888/ShoppingCarControllor/deletegoods_id";
				self.$axios.post(url, formData, {
					headers: {
						'Content-Type': 'application/json;charset=UTF-8'
					}
				}).then(function(response) {
					console.log(response);
				});
				self.$router.go(0)
				//self.searchshoppingcar();
			},

			DeleteSelected() {
				for(var i = 0; i < this.checkItem.length; i++) {
					var self = this
					let formData = JSON.stringify({
						shopping_car_id: this.checkItem[i]
					});
					var url = "http://localhost:8888/SettlementControllor/Delete_Selected";
					self.$axios.post(url, formData, {
						headers: {
							'Content-Type': 'application/json;charset=UTF-8'
						}
					}).then(function(response) {
						console.log(response);
					});
				}
			},

			Settlement() {
				var self = this
				let formData = JSON.stringify(self.input);
				var url = "http://localhost:8888/SettlementControllor/OrderDetial";
				self.$axios.post(url, formData, {
					headers: {
						'Content-Type': 'application/json;charset=UTF-8'
					}
				}).then(function(response) {
					console.log(response);
				});
				self.DeleteSelected();
			},

			searchshoppingcar: function() {
				var self = this;
				self.$axios.post('http://localhost:8888/ShoppingCarControllor/getAllShoppingCarInfo')
					.then(response => {
						self.infoList = response.data
					})
					.catch(function(error) { // 请求失败处理
						console.log(error);
					});

			},

			add: function(index) {
				//this.infoList[index].goods_number++
				var url = "http://localhost:8888/goods/goodsinfo/";
				this.$axios.post(url, JSON.stringify({
						goods_id: this.infoList[index].goods_id
					}), {
						headers: {
							'Content-Type': 'application/json;charset=UTF-8'
						}
					})
					.then(response => {
						this.maxstore = response.data.goods_store;
						if(this.infoList[index].goods_number < this.maxstore)
							this.infoList[index].goods_number++;
						else if(this.infoList[index].goods_number > this.maxstore) {
							alert("超预存,请刷新页面重新选择。");
						}
					});
			},

			reduce: function(index) {
				if(this.infoList[index].goods_number <= 0) {
					this.infoList[index].goods_number = 0
				} else {
					this.infoList[index].goods_number--
				}
			},

			selectOne(index) {
				if(this.checkItem.length == this.infoList.length) {
					this.checkAll = true
				} else {
					this.checkAll = false
				}
				if(this.infoList[index].isbuy) {
					this.infoList[index].isbuy = false
					this.input.orderDetail.splice(index, 1);
				} else {
					this.infoList[index].isbuy = true
					this.input.orderDetail.push(this.infoList[index])
				}
			},

			selectAll() {
				this.checkItem = []
				if(!this.checkAll) {
					for(var i = 0; i < this.infoList.length; i++) {
						this.checkItem.push(this.infoList[i].shopping_car_id)
						this.input.orderDetail.push(this.infoList[i])
						this.infoList[i].isbuy = true
					}
				} else {
					this.checkItem = []
					this.checkAll = false
					for(var i = 0; i < this.infoList.length; i++) {
						this.input.orderDetail.splice(i, 1);
						this.infoList[i].isbuy = false
					}
				}
			},

			getSession() {
				var url = "http://localhost:8888/goods/getUserSession/";
				this.$axios.get(url)
					.then(response => {
						var userInfo = response.data;
						if(userInfo != "") {
							this.loginStatus = "退出登录";
							this.userId = userInfo.userId;
						}
					})
			},

			loginAndOut() {
				if(this.loginStatus == "你好，请登录") {
					this.$router.push({
						path: '/login'
					});
				} else {
					this.$axios.get("http://localhost:8888/user/logout/?userId=" + this.userId)
						.then(response => {
							this.$router.push({
								path: '/login'
							});
						})
				}
			}
		},

		computed: {
			sum() {
				var total = 0
				for(var i = 0; i < this.infoList.length; i++) {
					if(this.infoList[i].isbuy) {
						total += parseFloat(this.infoList[i].goods_price) * parseFloat(this.infoList[i].goods_number)
					}
				}
				this.input.order_sum = total
				return total
			},

			count: function() {
				var total = 0
				for(var i = 0; i < this.infoList.length; i++) {
					if(this.infoList[i].isbuy) {
						total += parseInt(this.infoList[i].goods_number)
					}
				}
				return total
			}
		}
	}
</script>
<style scoped>
	li {
		overflow: hidden;
		float: left;
		text-decoration: none;
		width: 85px;
		text-align: center;
	}
	
	a {
		text-decoration: none;
	}
	
	.head {
		width: 100%;
		padding-top: 5px;
		height: 25px;
		background-color: #E3E4E5;
	}
	
	.head_first {
		padding-left: 100px;
		float: left;
	}
	
	.head_second {
		padding-left: 500px;
		font-size: 12px;
		color: #F2F2F2;
	}
	
	.head_second_li {
		overflow: hidden;
		float: left;
		text-decoration: none;
		width: 10px;
		text-align: center;
	}
	
	.head_second_li_1 ul {
		float: left;
		margin: 0;
		padding: 0;
		visibility: hidden;
		background-color: #FFFFFF;
	}
	
	.head_second_li_1:hover ul {
		visibility: visible;
	}
	
	.second {
		width: 100%;
		height: 75px;
		padding-top: 25px;
	}
	
	.second_a_1 {
		position: absolute;
		left: 300px;
	}
	
	.second_a_2 {
		position: absolute;
		left: 450px;
		top: 74px;
	}
	
	.second_input_1 {
		position: absolute;
		left: 950px;
		top: 74px;
		width: 260px;
		height: 22px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		border: 2px solid #c91623;
	}
	
	.second_button_1 {
		position: absolute;
		left: 1215px;
		top: 74px;
		width: 55px;
		height: 28px;
		background-color: #c91623;
		border: none;
		color: white;
	}
	
	.body {
		height: 600px;
		text-align: center;
	}
	
	.body_font_1 {
		position: absolute;
		top: 50%;
		left: 40%;
	}
	
	.body_div_1 {
		position: absolute;
		top: 150px;
		left: 300px;
		width: 970px;
		;
		height: 500px;
	}
	
	.body_div_1_font_1 {
		float: left;
		line-height: 26px;
		font-weight: 700;
		font-size: 16px;
		color: #E2231A;
	}
	
	.body_div_1_div_1 {
		position: absolute;
		top: 25px;
		width: 100%;
		padding-top: 10px;
		height: 30px;
		background-color: #F3F3F3;
		border: 1px solid #e9e9e9;
	}
	
	.body_div_1_div_1_input_1 {
		float: left;
		position: absolute;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_1_font_1 {
		position: absolute;
		left: 25px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_1_font_2 {
		position: absolute;
		left: 200px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_1_font_3 {
		position: absolute;
		left: 400px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_1_font_4 {
		position: absolute;
		left: 600px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_1_font_5 {
		position: absolute;
		left: 750px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_1_font_6 {
		position: absolute;
		left: 860px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		color: #666;
	}
	
	.body_div_1_div_2 {
		position: absolute;
		top: 80px;
		padding-top: 10px;
		width: 970px;
		height: 90px;
	}
	
	.body_div_1_img_1 {
		margin-left: 10px;
		float: left;
		width: 80px;
		height: 80px;
	}
	
	.body_div_1_div_2_div_1 {
		float: left;
		width: 200px;
		margin-left: 200px;
		height: 80px;
		line-height: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		text-align: left;
	}
	
	.body_div_1_div_2_div_1_a_1:hover {
		color: red;
	}
	
	.body_div_1_div_2_div_2 {
		float: left;
		width: 120px;
		margin-left: 20px;
		height: 80px;
		line-height: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		text-align: left;
	}
	
	.body_div_1_div_2_div_3 {
		float: left;
		width: 100px;
		margin-left: 40px;
		height: 80px;
		line-height: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_1_div_2_div_4 {
		float: left;
		width: 100px;
		margin-left: 30px;
		height: 80px;
		line-height: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_1_div_2_div_4_input_1 {
		border: 1px solid #cacbcb;
		color: #666;
	}
	
	.body_div_1_div_2_div_4_input_2 {
		border: 1px solid #cacbcb;
		width: 40px;
		height: 15px;
		line-height: 18px;
		text-align: center;
		margin: 0;
		font-size: 12px;
		font-family: verdana;
		color: #333;
	}
	
	.body_div_1_div_2_div_4_input_3 {
		border: 1px solid #cacbcb;
		color: #666;
	}
	
	.body_div_1_div_2_div_5 {
		float: left;
		width: 100px;
		margin-left: 30px;
		height: 80px;
		line-height: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_1_div_2_div_6 {
		float: left;
		width: 80px;
		margin-left: 20px;
		height: 80px;
		line-height: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
		text-align: left;
	}
	
	.body_div_2 {
		position: absolute;
		top: 340px;
		left: 300px;
		padding-top: 10px;
		width: 970px;
		height: 42px;
		text-align: left;
		border: 1px solid #e9e9e9;
	}
	
	.body_div_2_input_1 {
		margin-top: 11px;
		vertical-align: middle;
	}
	
	.body_div_2_font_1 {
		position: absolute;
		top: 18px;
		left: 20px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_2_a_1 {
		position: absolute;
		top: 18px;
		left: 70px;
		line-height: 50px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_2_a_2 {
		position: absolute;
		top: 18px;
		left: 170px;
		line-height: 50px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_2_a_3 {
		position: absolute;
		top: 18px;
		left: 260px;
		line-height: 50px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_2_font_2 {
		color: #999;
		position: absolute;
		top: 10px;
		left: 650px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_2_font_3 {
		color: #999;
		position: absolute;
		top: 10px;
		left: 750px;
		font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB, "\u5b8b\u4f53", sans-serif;
	}
	
	.body_div_2_font_4 {
		font-size: 16px;
		color: #E2231A;
		font-weight: 700;
		position: absolute;
		top: 10px;
		left: 790px;
	}
	
	.body_div_2_a_4 {
		position: absolute;
		top: -580px;
		right: 100px;
		width: 95px;
		height: 50px;
		background-image: url(../../static/images/cart-submit-btn-2018.png);
	}
	
	.selementcar {
		position: absolute;
		right: 0px;
		text-align: right;
	}
	
	.third {
		position: absolute;
		top: 650px;
		width: 100%;
		height: 200px;
		text-align: center;
	}
	
	.third_hr_1 {
		width: 70%;
	}
	
	.third_ul_1 {
		position: absolute;
		color: #999;
		left: 50px;
		font-size: 12px;
	}
	
	.third_font_1 {
		position: absolute;
		left: 350px;
		top: 100px;
		font-size: 12px;
		color: #999;
	}
</style>